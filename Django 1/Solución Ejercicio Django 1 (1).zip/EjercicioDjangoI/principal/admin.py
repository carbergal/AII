from django.contrib import admin
from principal.models import Temporada,Jornada,Partido,Equipo

admin.site.register(Jornada)
admin.site.register(Partido)
admin.site.register(Temporada)
admin.site.register(Equipo)
