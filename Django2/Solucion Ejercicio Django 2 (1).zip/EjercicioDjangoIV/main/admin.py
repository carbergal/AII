from main.models import Vino,Pais,Denominacion,Uva
from django.contrib import admin

admin.site.register(Vino)
admin.site.register(Pais)
admin.site.register(Denominacion)
admin.site.register(Uva)

